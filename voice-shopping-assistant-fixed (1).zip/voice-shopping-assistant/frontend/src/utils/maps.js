// small map used in frontend categorization
export const categoryMap = {
  dairy:["milk","cheese","yogurt","butter"],
  produce:["apple","banana","orange","spinach","tomato","potato","onion"],
  bakery:["bread","croissant","bagel"],
  beverages:["water","juice","coffee","tea"],
  snacks:["chips","biscuits","chocolate"],
  household:["detergent","soap","toothpaste"]
};

export function categorize(name){
  const n = name.toLowerCase();
  for(const k of Object.keys(categoryMap)){
    if(categoryMap[k].some(w=> n.includes(w))) return k;
  }
  return "uncategorized";
}
