// Very small, human-authored rule-based parser.
// Handles commands like:
//  - "Add 2 bottles of water"
//  - "I need milk"
//  - "Remove milk"
//  - "Find organic apples under 5 dollars"

export function parseCommand(text=""){
  const t = text.toLowerCase().trim();
  // add commands
  const addMatch = t.match(/(?:add|put|i need|i want to buy|i want|buy)\s+(\d+)?\s*(?:x|pcs|bottles|bottle|kg|g|kg|loaves|loaf)?\s*(?:of\s+)?(.+)/);
  if(addMatch){
    const q = addMatch[1] ? parseInt(addMatch[1],10) : 1;
    const item = addMatch[2].trim().replace(/^(a|an)\s+/,"");
    // attempt to split quantity units
    const unitMatch = item.match(/(.+)\s+(bottle|bottles|kg|g|loaf|loaves|pack)$/);
    let unit = "";
    let name = item;
    if(unitMatch){ name = unitMatch[1]; unit = unitMatch[2]; }
    return {action:"add", item: name.replace(/\.$/,""), quantity: q, unit};
  }

  // remove
  const removeMatch = t.match(/(?:remove|delete|take off|dont buy|don't buy)\s+(.+)/);
  if(removeMatch) return {action:"remove", item: removeMatch[1].trim().replace(/\.$/,"")};

  // search/price
  const searchMatch = t.match(/(?:find|search for|show me)\s+(.*?)(?:\s+under\s+\$?(\d+(?:\.\d+)?))?$/);
  if(searchMatch) return {action:"search", item: searchMatch[1].trim(), maxPrice: searchMatch[2] ? parseFloat(searchMatch[2]) : undefined};

  return {action:"unknown"};
}
