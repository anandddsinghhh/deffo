import React, {useEffect, useState} from "react";
import VoiceControl from "./components/VoiceControl";
import ShoppingList from "./components/ShoppingList";
import SearchBar from "./components/SearchBar";
import axios from "axios";

const API = import.meta.env.VITE_API || "http://localhost:8080";

export default function App(){
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [suggestions, setSuggestions] = useState([]);

  useEffect(()=>{ fetchItems(); fetchSuggestions(); }, []);

  async function fetchItems(){
    setLoading(true);
    try{
      const res = await axios.get(`${API}/api/items`);
      if(res.data.ok) setItems(res.data.items);
    }catch(e){
      console.error(e);
      alert("Could not fetch items");
    }finally{ setLoading(false); }
  }

  async function fetchSuggestions(){
    try{
      const res = await axios.get(`${API}/api/suggestions`);
      if(res.data.ok) setSuggestions(res.data.suggestions);
    }catch(e){ console.error(e); }
  }

  async function addItem(payload){
    // payload: {name,quantity,unit,category,meta}
    setLoading(true);
    try{
      const res = await axios.post(`${API}/api/items`, payload);
      if(res.data.ok){ setItems(prev=>[...prev, res.data.item]); }
    }catch(e){ console.error(e); alert("Add failed"); }
    finally{ setLoading(false); }
  }

  async function removeItem(id){
    setLoading(true);
    try{
      await axios.delete(`${API}/api/items/${id}`);
      setItems(prev=>prev.filter(i=>i.id!==id));
    }catch(e){ console.error(e); }
    finally{ setLoading(false); }
  }

  return (
    <div className="container">
      <h1>Voice Command Shopping Assistant</h1>
      <div className="panel">
        <VoiceControl onCommand={addItem} api={API}/>
        <SearchBar api={API}/>
      </div>
      <div className="panel">
        <h2>Suggestions</h2>
        <div className="suggestions">
          {suggestions.length ? suggestions.map(s=>(
            <button key={s.name} className="pill" onClick={()=>addItem({name:s.name, quantity:1, unit:"", category:"", meta:{}})}>
              {s.name} {s.score ? `({s.score})` : ""}
            </button>
          )) : <em>No suggestions</em>}
        </div>
      </div>

      <ShoppingList items={items} loading={loading} onRemove={removeItem}/>
      <footer style={{marginTop:20, fontSize:12}}>Minimalist UI • Visual feedback shown as you speak.</footer>
    </div>
  );
}
