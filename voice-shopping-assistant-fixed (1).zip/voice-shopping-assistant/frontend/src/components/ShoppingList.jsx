import React from "react";

export default function ShoppingList({items, loading, onRemove}){
  return (
    <div className="panel">
      <h2>Shopping List</h2>
      {loading ? <div className="loader">Loading…</div> : null}
      <ul className="list">
        {items.map(it=>(
          <li key={it.id} className="list-item">
            <div>
              <strong>{it.name}</strong> {it.quantity ? `x${it.quantity}` : ""} <span className="muted">({it.category||"uncategorized"})</span>
              <div className="meta">{it.meta && it.meta.brand ? it.meta.brand : ""} {it.meta && it.meta.price ? `· $${it.meta.price}` : ""}</div>
            </div>
            <div>
              <button className="small" onClick={()=>onRemove(it.id)}>Remove</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
