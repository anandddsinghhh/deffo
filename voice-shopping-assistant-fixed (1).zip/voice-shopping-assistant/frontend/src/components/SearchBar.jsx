import React, {useState} from "react";
import axios from "axios";
export default function SearchBar({api}){
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [maxPrice, setMaxPrice] = useState("");

  async function doSearch(e){
    e.preventDefault();
    try{
      const res = await axios.get(`${api}/api/search`, { params: { q: query, maxPrice: maxPrice || undefined }});
      if(res.data.ok) setResults(res.data.items);
    }catch(e){ console.error(e); alert("Search failed"); }
  }

  return (
    <div className="search">
      <form onSubmit={doSearch}>
        <input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Find item e.g. organic apples"/>
        <input value={maxPrice} onChange={e=>setMaxPrice(e.target.value)} placeholder="Max price (optional)" style={{width:120}}/>
        <button>Search</button>
      </form>
      <div>
        {results.map(r=>(
          <div key={r.id} className="search-result">
            {r.name} {r.meta && r.meta.price ? `- $${r.meta.price}` : ""}
          </div>
        ))}
      </div>
    </div>
  );
}
