import React, {useEffect, useState, useRef} from "react";
import { parseCommand } from "../utils/nlp";

export default function VoiceControl({onCommand, api}){
  const [listening, setListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [lang, setLang] = useState("en-IN");
  const recognitionRef = useRef(null);

  useEffect(()=>{
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if(!SpeechRecognition){
      recognitionRef.current = null;
      return;
    }
    const rec = new SpeechRecognition();
    rec.continuous = false;
    rec.interimResults = false;
    rec.lang = lang;
    rec.onresult = (e)=>{
      const text = e.results[0][0].transcript;
      setTranscript(text);
      handleText(text);
    };
    rec.onerror = (e)=>{ console.error("speech error", e); setListening(false); };
    recognitionRef.current = rec;
  }, [lang]);

  function startListening(){
    if(!recognitionRef.current){ alert("Speech API not supported in this browser."); return; }
    setTranscript("");
    setListening(true);
    recognitionRef.current.lang = lang;
    recognitionRef.current.start();
  }
  function stopListening(){
    if(recognitionRef.current) recognitionRef.current.stop();
    setListening(false);
  }

  function handleText(text){
    // parse into item add/remove/search
    const cmd = parseCommand(text);
    if(cmd && cmd.action === "add"){
      onCommand({name:cmd.item, quantity:cmd.quantity||1, unit:cmd.unit||"", category:cmd.category||"", meta:{}})
    }else if(cmd && cmd.action === "remove"){
      // for simplicity, call a web search to find item id is left to list UI
      alert(`Say 'remove <item>' is recognized: ${cmd.item}. Remove from list manually from the list for now.`);
    }else if(cmd && cmd.action === "search"){
      alert(`Search requested: ${cmd.item}`);
    }else{
      alert("Sorry, couldn't parse that command. Try 'Add 2 apples' or 'Remove milk'.");
    }
  }

  return (
    <div className="voicebox">
      <div className="controls">
        <label>
          Language
          <select value={lang} onChange={e=>setLang(e.target.value)}>
            <option value="en-IN">English (India)</option>
            <option value="en-US">English (US)</option>
            <option value="hi-IN">Hindi</option>
            <option value="es-ES">Spanish</option>
          </select>
        </label>
        {!listening ? (
          <button onClick={startListening} className="record">🎤 Start Listening</button>
        ) : (
          <button onClick={stopListening} className="stop">⏹ Stop</button>
        )}
      </div>
      <div className="transcript">
        <strong>Transcript:</strong> {transcript || <em>Say: "Add 2 bottles of water"</em>}
      </div>
    </div>
  );
}
