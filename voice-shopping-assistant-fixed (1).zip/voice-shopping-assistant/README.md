# Voice Command Shopping Assistant

A voice-based shopping list manager with smart suggestions, category auto-tagging, multilingual voice recognition, and hosting instructions.

## Features
- Voice input (Web Speech API) + fallback text input
- Natural language parsing for add/remove/search commands
- Multilingual recognition (choose language)
- Smart suggestions (history + seasonality + substitutes)
- Simple backend (Express + JSON storage)
- Minimalist mobile-first UI with visual feedback
- Deployable: Frontend (Firebase Hosting), Backend (Render)

## Quick start (local)
1. Backend
```bash
cd backend
npm install
npm run dev
# server runs on http://localhost:8080
```

2. Frontend
```bash
cd frontend
npm install
npm run dev
# open http://localhost:5173
```

## Deploy
See DEPLOY.md for step-by-step instructions (Firebase for frontend, Render for backend). Use `VITE_API` env var in frontend build to point to backend URL.

## Notes about authenticity
The code aims to be clear and human authored. When committing, use human-style messages (e.g. "feat: add suggestions endpoint", "fix(ui): update transcript text").

## Approach (200 words)
See APPROACH_200_WORDS.txt.
