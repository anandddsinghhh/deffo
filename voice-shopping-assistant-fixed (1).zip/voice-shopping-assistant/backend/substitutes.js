// simple substitute mapping
module.exports = {
  milk: ["almond milk","soya milk","oat milk"],
  bread: ["whole grain bread","multigrain bread"],
  sugar: ["jaggery","honey"],
  butter: ["margarine"]
};
