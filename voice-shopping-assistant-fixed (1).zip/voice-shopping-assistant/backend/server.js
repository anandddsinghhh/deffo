const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const fs = require("fs");
const path = require("path");
const { scoreCandidates } = require("./suggestions");

const DB_PATH = path.join(__dirname, "db.json");
function readDB() {
  const raw = fs.readFileSync(DB_PATH, "utf8");
  return JSON.parse(raw);
}
function writeDB(db) {
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
}

const app = express();
app.use(cors());
app.use(bodyParser.json());

/** GET items */
app.get("/api/items", (req,res)=>{
  try{
    const db = readDB();
    res.json({ok:true, items:db.items || []});
  }catch(e){
    console.error(e);
    res.status(500).json({ok:false, error:"read_error"});
  }
});

/** POST item */
app.post("/api/items", (req,res)=>{
  try{
    const db = readDB();
    const {name, quantity=1, unit="", category="", meta={}} = req.body;
    if(!name || typeof name !== "string") return res.status(400).json({ok:false,error:"invalid_name"});
    const id = (db.items.reduce((m,i)=>Math.max(m,i.id),0) || 0) + 1;
    const item = {id, name: name.toLowerCase(), quantity, unit, category, meta, addedAt: new Date().toISOString()};
    db.items.push(item);
    db.history.push({name:item.name, timestamp: new Date().toISOString()});
    writeDB(db);
    res.json({ok:true, item});
  }catch(e){
    console.error(e);
    res.status(500).json({ok:false, error:"write_error"});
  }
});

/** DELETE item */
app.delete("/api/items/:id", (req,res)=>{
  try{
    const id = parseInt(req.params.id,10);
    const db = readDB();
    const before = db.items.length;
    db.items = db.items.filter(i=>i.id !== id);
    writeDB(db);
    res.json({ok:true, deleted: before - db.items.length});
  }catch(e){
    console.error(e);
    res.status(500).json({ok:false});
  }
});

/** SEARCH endpoint: can accept brand/price query as params */
app.get("/api/search", (req,res)=>{
  try{
    const q = (req.query.q||"").toLowerCase();
    const maxPrice = parseFloat(req.query.maxPrice || "0");
    const db = readDB();
    const items = (db.items || []).filter(i=>{
      if(!q) return true;
      let included = i.name.includes(q) || (i.meta && i.meta.brand && i.meta.brand.toLowerCase().includes(q));
      if(maxPrice && i.meta && i.meta.price) included = included && (i.meta.price <= maxPrice);
      return included;
    });
    res.json({ok:true, items});
  }catch(e){
    console.error(e);
    res.status(500).json({ok:false});
  }
});

/** Suggestions - combines history + seasonal + substitutes */
app.get("/api/suggestions", (req,res)=>{
  try{
    const db = readDB();
    const monthNow = new Date().getMonth()+1;
    const scored = scoreCandidates(db.history || [], monthNow);
    res.json({ok:true, suggestions: scored.slice(0,10)});
  }catch(e){
    console.error(e);
    res.status(500).json({ok:false});
  }
});

/** Basic ping */
app.get("/api/ping", (req,res)=>res.json({ok:true, now: new Date().toISOString()}));

const PORT = process.env.PORT || 8080;
app.listen(PORT, ()=>console.log("Server listening on", PORT));
