const categories = require("./categories");
const substitutes = require("./substitutes");

function monthSeasonalItems(month) {
  // month: 1-12
  const seasonal = {
    1: ["oranges", "spinach"],
    2: ["strawberries", "spinach"],
    3: ["mango"],
    4: ["mango"],
    5: ["mango"],
    6: ["watermelon"],
    7: ["watermelon"],
    8: ["apple"],
    9: ["pear"],
    10: ["pumpkin"],
    11: ["citrus"],
    12: ["citrus"]
  };
  return seasonal[month] || [];
}

function scoreCandidates(history, monthNow) {
  const freq = {};
  history.forEach(h => {
    const name = h.name.toLowerCase();
    freq[name] = (freq[name]||0) + 1;
  });

  const results = [];
  // history top items
  Object.keys(freq).forEach(k => {
    results.push({name:k,score: 10 + freq[k]});
  });

  // seasonal
  monthSeasonalItems(monthNow).forEach(item => {
    results.push({name:item,score:8});
  });

  // add substitutes opportunistically
  Object.keys(substitutes).forEach(k=>{
    substitutes[k].forEach(s => results.push({name:s,score:5}));
  });

  // dedupe and sort
  const map = {};
  results.forEach(r => {
    const n = r.name;
    map[n] = Math.max(map[n]||0, r.score);
  });

  return Object.keys(map).map(n => ({name:n,score:map[n]})).sort((a,b)=>b.score-a.score);
}

module.exports = { scoreCandidates, monthSeasonalItems };
