// simple mapping for categories used by backend & frontend
module.exports = {
  dairy: ["milk","cheese","yogurt","butter"],
  produce: ["apple","banana","orange","spinach","tomato","potato","onion"],
  bakery: ["bread","croissant","bagel"],
  beverages: ["water","juice","coffee","tea"],
  snacks: ["chips","biscuits","chocolate"],
  household: ["detergent","soap","toothpaste"]
};
