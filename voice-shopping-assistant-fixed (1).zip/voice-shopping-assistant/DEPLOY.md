# Deploy Instructions

## Backend — Deploy to Render
1. Create a new GitHub repo and push the `backend/` folder as `/backend`.
2. On Render:
   - New -> Web Service -> Connect to GitHub -> select repo -> Choose branch.
   - Build command: `npm install`
   - Start command: `npm start`
   - Render will provide a public URL like `https://vcs-backend.onrender.com`
3. Ensure `db.json` is part of repo (note: Render's ephemeral filesystem — for persistent data use a DB; for assignment it's fine).

## Frontend — Deploy to Firebase Hosting
1. Install Firebase CLI:
```bash
npm install -g firebase-tools
firebase login
```
2. Build frontend:
```bash
cd frontend
npm install
npm run build
```
3. Initialize Firebase in project root (or frontend folder):
```bash
firebase init hosting
# choose build output folder: dist
```
4. Before deploying, set backend URL for the build:
```bash
# create a .env.production in frontend
echo "VITE_API=https://vcs-backend.onrender.com" > frontend/.env.production
# Then rebuild
cd frontend
npm run build
```
5. Deploy:
```bash
firebase deploy --only hosting
```

## Notes
- If you prefer Render for frontend too, serve the `dist` folder using a static site service.
- For production persistence, swap JSON file for a DB (sqlite / postgres). For evaluation a JSON file is acceptable.
